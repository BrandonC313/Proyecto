-- creacion de la BD 

CREATE DATABASE universidad;
 USE universidad;

 go 

-- Seleccionar la base de datos
USE universidad;

-- Crear la tabla notas en SQL Server

cREATE TABLE nota (
    ID INT PRIMARY KEY ,
    NombreCompleto VARCHAR(100) NOT NULL,
    Edad INT NOT NULL,
    Nota1Parcial FLOAT NOT NULL,
    Nota2Parcial FLOAT NOT NULL,
    Nota3Parcial FLOAT NOT NULL,
    NotaFinal FLOAT,
    Estado VARCHAR(45)
);

-- se crear un trigger para calcular NotaFinal y Estado
CREATE TRIGGER trg_CalcularNotas
ON notas
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

	--usando notas se definen los criterios visto en bases2 
    UPDATE notas
    SET 
        NotaFinal = INSERTED.Nota1Parcial * 0.2 + INSERTED.Nota2Parcial * 0.3 + INSERTED.Nota3Parcial * 0.5,
        Estado = CASE
            WHEN (INSERTED.Nota1Parcial * 0.2 + INSERTED.Nota2Parcial * 0.3 + INSERTED.Nota3Parcial * 0.5) >= 70 THEN 'Aprobado Felicidades'
            ELSE 'Reprobado'
        END
    FROM 
        notas
    INNER JOIN 
        INSERTED ON notas.ID = INSERTED.ID;
END;



