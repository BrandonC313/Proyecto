package Principal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
/**
 *
 * @author brand
 */

public class NotaView extends JFrame {
    // Componentes de la UI
    private JTextField txtNombreCompleto = new JTextField(20);
    private JTextField txtEdad = new JTextField(2);
    private JTextField txtNota1Parcial = new JTextField(5);
    private JTextField txtNota2Parcial = new JTextField(5);
    private JTextField txtNota3Parcial = new JTextField(5);
    private JTextField txtNotaFinal = new JTextField(5);
    private JTextField txtEstado = new JTextField(10);
    private JTable table = new JTable();
    private JButton btnCalcular = new JButton("Calcular");
    private JButton btnGuardar = new JButton("Guardar");
    private JButton btnEditar = new JButton("Editar");
    private JButton btnCancelar = new JButton("Cancelar");
    private JButton btnRefrescar = new JButton("Refrescar");
    private JButton btnEliminar = new JButton("Eliminar");
    private JButton btnBuscar = new JButton("Buscar");

    public NotaView() {
        // Configuración de la ventana
        this.setTitle("Catálogo de Notas de Estudiantes");
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel de entrada de datos
        JPanel panelInput = new JPanel(new GridLayout(8, 2));
        panelInput.add(new JLabel("Nombre Completo:"));
        panelInput.add(txtNombreCompleto);
        panelInput.add(new JLabel("Edad:"));
        panelInput.add(txtEdad);
        panelInput.add(new JLabel("Nota del I Parcial:"));
        panelInput.add(txtNota1Parcial);
        panelInput.add(new JLabel("Nota del II Parcial:"));
        panelInput.add(txtNota2Parcial);
        panelInput.add(new JLabel("Nota del III Parcial:"));
        panelInput.add(txtNota3Parcial);
        panelInput.add(new JLabel("Nota Final:"));
        panelInput.add(txtNotaFinal);
        panelInput.add(new JLabel("Estado:"));
        panelInput.add(txtEstado);

        // Panel de botones
        JPanel panelButtons = new JPanel();
        panelButtons.add(btnCalcular);
        panelButtons.add(btnGuardar);
        panelButtons.add(btnEditar);
        panelButtons.add(btnCancelar);
        panelButtons.add(btnRefrescar);
        panelButtons.add(btnEliminar);
        panelButtons.add(btnBuscar);

        // Panel principal
        JPanel panelMain = new JPanel(new BorderLayout());
        panelMain.add(panelInput, BorderLayout.NORTH);
        panelMain.add(new JScrollPane(table), BorderLayout.CENTER);
        panelMain.add(panelButtons, BorderLayout.SOUTH);

        this.add(panelMain);
    }

    // Métodos para acceder a los componentes de la UI
    public String getNombreCompleto() {
        return txtNombreCompleto.getText();
    }

    public int getEdad() {
        return Integer.parseInt(txtEdad.getText());
    }

    public double getNota1Parcial() {
        return Double.parseDouble(txtNota1Parcial.getText());
    }

    public double getNota2Parcial() {
        return Double.parseDouble(txtNota2Parcial.getText());
    }

    public double getNota3Parcial() {
        return Double.parseDouble(txtNota3Parcial.getText());
    }

    public void setNotaFinal(double notaFinal) {
        txtNotaFinal.setText(String.valueOf(notaFinal));
    }

    public void setEstado(String estado) {
        txtEstado.setText(estado);
    }

    public JTable getTable() {
        return table;
    }

    // Métodos para añadir action listeners
    public void addCalcularListener(ActionListener listener) {
        btnCalcular.addActionListener(listener);
    }

    public void addGuardarListener(ActionListener listener) {
        btnGuardar.addActionListener(listener);
    }

    public void addEditarListener(ActionListener listener) {
        btnEditar.addActionListener(listener);
    }

    public void addCancelarListener(ActionListener listener) {
        btnCancelar.addActionListener(listener);
    }

    public void addRefrescarListener(ActionListener listener) {
        btnRefrescar.addActionListener(listener);
    }

    public void addEliminarListener(ActionListener listener) {
        btnEliminar.addActionListener(listener);
    }

    public void addBuscarListener(ActionListener listener) {
        btnBuscar.addActionListener(listener);
    }
}

