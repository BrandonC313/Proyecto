/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author brand
 */
class Nota {
    
     private int id;
    private String nombreCompleto;
    private int edad;
    private double nota1Parcial;
    private double nota2Parcial;
    private double nota3Parcial;
    private double notaFinal;
    private String estado;

  
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getNota1Parcial() {
        return nota1Parcial;
    }

    public void setNota1Parcial(double nota1Parcial) {
        this.nota1Parcial = nota1Parcial;
    }

    public double getNota2Parcial() {
        return nota2Parcial;
    }

    public void setNota2Parcial(double nota2Parcial) {
        this.nota2Parcial = nota2Parcial;
    }

    public double getNota3Parcial() {
        return nota3Parcial;
    }

    public void setNota3Parcial(double nota3Parcial) {
        this.nota3Parcial = nota3Parcial;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    // Conexión a la base de datos usando localhost como estoy usando mi pc 
    public Connection connect() {
        // hacer el string de la base de datos, localhost usado para mi pclocal
        String url = "jdbc:sqlserver://localhost;databaseName=universidad;integratedSecurity=true;";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
            JOptionPane.showMessageDialog(null, "Este es un mensaje de información.", "Título del Mensaje", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Por favor verifique: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error");
        }
        return conn;
        
    }

     // Métodos CRUD
    public void insertarNotas(String nombreCompleto, int ID, int edad, double nota1Parcial, double nota2Parcial, double nota3Parcial) {
        String sql = "INSERT INTO nota (NombreCompleto,ID, Edad, Nota1Parcial, Nota2Parcial, Nota3Parcial) VALUES (?, ?, ?, ?, ?,?)";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreCompleto);
            pstmt.setInt(2, ID);
            pstmt.setInt(2, edad);
            pstmt.setDouble(3, nota1Parcial);
            pstmt.setDouble(4, nota2Parcial);
            pstmt.setDouble(5, nota3Parcial);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Por favor verifique: " + e.getMessage());
        }
    }

    public void actualizarNotas() {
        String sql = "UPDATE notas SET NombreCompleto = ?, Edad = ?, Nota1Parcial = ?, Nota2Parcial = ?, Nota3Parcial = ? WHERE ID = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreCompleto);
            pstmt.setInt(2, edad);
            pstmt.setDouble(3, nota1Parcial);
            pstmt.setDouble(4, nota2Parcial);
            pstmt.setDouble(5, nota3Parcial);
            pstmt.setInt(6, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Por favor verifique: " + e.getMessage());
        }
    }

    public void eliminarNota() {
        String sql = "DELETE FROM notas WHERE ID = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Por favor verifique: " + e.getMessage());
        }
    }

    public ResultSet obtenerNotas() {
        String sql = "SELECT * FROM notas";
        ResultSet rs = null;
        try {
            Connection conn = this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
        } catch (SQLException e) {
            System.out.println("Por favor verifique: " + e.getMessage());
        }
        return rs;
    }
    
}
