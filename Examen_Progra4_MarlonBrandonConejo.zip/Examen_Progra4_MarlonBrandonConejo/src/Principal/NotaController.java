package Principal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author brand
 */
public class NotaController {
    
    private Nota model;
    private NotaView view;

    public NotaController(Nota model, NotaView view) {
        this.model = model;
        this.view = view;

        // Añadir listeners a los botones
        this.view.addCalcularListener(new CalcularListener());
        this.view.addGuardarListener(new GuardarListener());
        this.view.addEditarListener(new EditarListener());
        this.view.addCancelarListener(new CancelarListener());
        this.view.addRefrescarListener(new RefrescarListener());
        this.view.addEliminarListener(new EliminarListener());
        this.view.addBuscarListener(new BuscarListener());
    }

    class CalcularListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double nota1 = view.getNota1Parcial();
            double nota2 = view.getNota2Parcial();
            double nota3 = view.getNota3Parcial();
            double notaFinal = nota1 * 0.2 + nota2 * 0.3 + nota3 * 0.5;
            view.setNotaFinal(notaFinal);
            view.setEstado(notaFinal >= 70 ? "Aprobado" : "Reprobado");
        }
    }

    class GuardarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            model.setNombreCompleto(view.getNombreCompleto());
            model.setEdad(view.getEdad());
            model.setNota1Parcial(view.getNota1Parcial());
            model.setNota2Parcial(view.getNota2Parcial());
            model.setNota3Parcial(view.getNota3Parcial());
           // model.insertarNotas();
            view.setNotaFinal(0);
            view.setEstado("");
        }
    }

    class EditarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            model.setNombreCompleto(view.getNombreCompleto());
            model.setEdad(view.getEdad());
            model.setNota1Parcial(view.getNota1Parcial());
            model.setNota2Parcial(view.getNota2Parcial());
            model.setNota3Parcial(view.getNota3Parcial());
            model.actualizarNotas();
            view.setNotaFinal(0);
            view.setEstado("");
        }
    }

    class CancelarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            view.setNotaFinal(0);
            view.setEstado("");
        }
    }

    class RefrescarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            DefaultTableModel modelTable = (DefaultTableModel) view.getTable().getModel();
            modelTable.setRowCount(0);
            ResultSet rs = model.obtenerNotas();
            try {
                while (rs.next()) {
                    modelTable.addRow(new Object[]{
                        rs.getInt("ID"),
                        rs.getString("NombreCompleto"),
                        rs.getInt("Edad"),
                        rs.getDouble("Nota1Parcial"),
                        rs.getDouble("Nota2Parcial"),
                        rs.getDouble("Nota3Parcial"),
                        rs.getDouble("NotaFinal"),
                        rs.getString("Estado")
                    });
                }
            } catch (SQLException ex) {
                System.out.println("Por favor verifique: " + ex.getMessage());
            }
        }
    }

    class EliminarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedRow = view.getTable().getSelectedRow();
            if (selectedRow != -1) {
                model.setId((int) view.getTable().getValueAt(selectedRow, 0));
                model.eliminarNota();
                ((DefaultTableModel) view.getTable().getModel()).removeRow(selectedRow);
            }
        }
    }

    class BuscarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String searchText = view.getNombreCompleto();
            DefaultTableModel modelTable = (DefaultTableModel) view.getTable().getModel();
            modelTable.setRowCount(0);
            ResultSet rs = model.obtenerNotas();
            try {
                while (rs.next()) {
                    if (rs.getString("NombreCompleto").contains(searchText)) {
                        modelTable.addRow(new Object[]{
                            rs.getInt("ID"),
                            rs.getString("NombreCompleto"),
                            rs.getInt("Edad"),
                            rs.getDouble("Nota1Parcial"),
                            rs.getDouble("Nota2Parcial"),
                            rs.getDouble("Nota3Parcial"),
                            rs.getDouble("NotaFinal"),
                            rs.getString("Estado")
                        });
                    }
                }
            } catch (SQLException ex) {
                System.out.println("Por favor verifique: " + ex.getMessage());
            }
        }
    }
}


