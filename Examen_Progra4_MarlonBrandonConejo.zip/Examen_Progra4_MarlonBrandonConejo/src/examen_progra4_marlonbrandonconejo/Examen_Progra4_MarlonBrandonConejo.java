/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen_progra4_marlonbrandonconejo;

/**
 *
 * @author brand
 */
public class Examen_Progra4_MarlonBrandonConejo {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
       /**
        Nota model = new Nota();
        NotaView view = new NotaView();
        NotaController controller = new NotaController(model, view);

        view.setVisible(true);   */
    }
    
}
